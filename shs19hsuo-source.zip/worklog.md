---
Task ID: main
Agent: main (Z.ai)
Task: Build a trilingual (fa/en/zh) English-learning PWA with chat-style UI, AI tutor, 1000+ words, Free Dictionary API integration, installable on Android.

Work Log:
- Loaded fullstack-dev skill, initialized project
- Built purple + turquoise theme in src/app/globals.css (light + dark variants)
- Created trilingual i18n string tables (fa/en/zh) in src/lib/i18n.ts with RTL/LTR metadata
- Wrote Python generator script (scripts/generate_words.py) producing 1170 common English words across 22 topics with fa + zh translations and CEFR levels — output saved to src/data/words.ts
- Implemented Zustand store (src/lib/store.ts) with persist middleware for locale, theme, learned words, and chat history
- Built API routes:
  - /api/dictionary: proxies Free Dictionary API with User-Agent header, falls back to Datamuse API when dictionaryapi.dev is blocked (Cloudflare 403)
  - /api/tutor: AI tutor chat via z-ai-web-dev-sdk with locale-aware system prompt
- Built components:
  - language-switcher.tsx (fa/en/zh dropdown + theme toggle + useT hook)
  - word-card.tsx (word, level, phonetic, audio, English definition, native translation, speak button, mark-learned)
  - chat-message.tsx (chat bubbles with bubble-in animation, typing indicator with pulse dots)
  - chat-input.tsx (auto-grow textarea, voice input via Web Speech API, suggestion chips)
  - topic-sidebar.tsx (22 topic chips with progress, search box, word list with learned indicators)
- Built main page (src/app/page.tsx) with sticky header, mobile drawer (Sheet) + desktop sidebar, chat area, About modal
- Updated layout.tsx with Inter + Noto Sans Arabic + Noto Sans SC fonts, PWA metadata, themeColor viewport
- Created PWA manifest (public/manifest.json) + SVG/PNG icons (192px + 512px via cairosvg)
- Fixed ESLint errors:
  - i18n.ts parsing error (curly Chinese quotes inside ASCII string)
  - setState-in-effect warnings (deferred via microtask / removed state indirection for static imports)
- Verified with Agent Browser:
  - App renders correctly with welcome message in Persian (RTL)
  - All 22 topics visible, click topic → word list loads with Persian translations
  - Click word → word card appears with English definition (via Datamuse fallback) + Persian translation
  - AI tutor chat works end-to-end: sent "Teach me the word 'adventure'" → received Persian response with English word bolded + example sentence + follow-up question
  - Language switcher works: tested Persian → English → Chinese (all 3 with proper dir/text)
  - Dictionary API tested: apple returns 200 with Datamuse definitions; adventure returns 200

Stage Summary:
- ✅ Lint clean (0 errors, 0 warnings)
- ✅ Dev server running on port 3000, no fatal errors
- ✅ All 3 languages verified working in browser
- ✅ AI tutor verified end-to-end
- ✅ Dictionary API verified with Datamuse fallback (since dictionaryapi.dev is Cloudflare-blocked in this env)
- ✅ 1170 words across 22 topics with full fa + zh translations + CEFR levels
- ✅ PWA manifest + icons installed
- Produced artifacts:
  - /home/z/my-project/src/ (full Next.js source)
  - /home/z/my-project/scripts/generate_words.py
  - /home/z/my-project/public/ (manifest.json, icon.svg, icon-192.png, icon-512.png)
  - /home/z/my-project/download/README.md (with GitHub push + Capacitor APK build instructions)
  - /home/z/my-project/download/screenshot-fa.png, screenshot-zh.png, screenshot-word-card.png
