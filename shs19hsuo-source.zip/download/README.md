# LingoPal — Learn 1000 English Words 🎓

A modern trilingual (Persian / English / Chinese) English-vocabulary learning PWA, with a chat-style UI, an AI tutor, and 1170+ words across 22 topics.

> Built with Next.js 16 + TypeScript + Tailwind CSS 4 + z-ai-web-dev-sdk.
> Live demo + APK builds powered by GitHub Actions (free).

## ✨ Features

- 🎨 **Modern purple + turquoise design** with gradient accents and bubble-style chat UI
- 🌐 **Trilingual UI** — switch instantly between فارسی (RTL), English (LTR), 中文 (LTR)
- 💬 **AI Tutor chat** — built on `z-ai-web-dev-sdk`, talks in your native language while always showing English words
- 📚 **1170+ words** across 22 topics (Food, Travel, Work, Family, Emotions, Nature, Body, Time, Education, Home, Animals, Sports, Clothes, Technology, Colors, Verbs, Adjectives, Adverbs, Numbers, Daily, Music, Hobbies)
- 🔤 **Live dictionary lookup** — Free Dictionary API with Datamuse fallback for definitions, phonetics, audio
- 🔊 **Pronunciation** — both native-speaker audio (when available) and browser speech synthesis
- 📊 **Progress tracking** — mark words as learned, see counts per topic
- 🎤 **Voice input** — speech-to-text for hands-free practice
- 📱 **PWA installable** — installable on Android/iOS home screen
- 🤖 **Auto APK builds** — every push to main triggers a GitHub Actions workflow that builds a downloadable Android APK — **free**

## 🚀 Run locally

```bash
bun install
bun run dev
# Open http://localhost:3000
```

## 📱 Download APK (free, no Android Studio needed)

Every push to the `main` branch automatically builds an APK via GitHub Actions:

1. Go to: https://github.com/ssijendn9-blip/shs19hsuo/actions
2. Click the latest **"Build Android APK"** workflow run
3. Scroll down to the **Artifacts** section at the bottom
4. Click **`lingopal-apk`** to download a ZIP containing `lingopal-debug.apk`
5. Unzip and install the APK on your Android phone (enable "Install from unknown sources" if needed)

> The first build may take 10–15 minutes. Subsequent builds are faster due to caching.

## 📦 Build APK locally (alternative)

If you have Android Studio + JDK 17 installed:

```bash
git clone https://github.com/ssijendn9-blip/shs19hsuo.git
cd shs19hsuo
bun install
bun add @capacitor/core @capacitor/cli @capacitor/android

# Edit next.config.ts to add: output: "export", images: { unoptimized: true }
bun run build
bunx cap init "LingoPal" "com.ssijendn9.lingopal" --web-dir=out
bunx cap add android
bunx cap sync android

cd android
./gradlew assembleDebug
# APK at: android/app/build/outputs/apk/debug/app-debug.apk
```

## 🌐 Deploy the web app

One-click deploy on Vercel (free):

1. Go to https://vercel.com/new
2. Import the GitHub repo `ssijendn9-blip/shs19hsuo`
3. Framework: **Next.js** (auto-detected)
4. Click **Deploy** — done in 60 seconds

You'll get a public URL like `https://shs19hsuo.vercel.app` — share it with anyone.

## 🗂 Project structure

```
src/
├── app/
│   ├── api/
│   │   ├── dictionary/route.ts   # Free Dictionary API + Datamuse fallback
│   │   └── tutor/route.ts        # AI tutor chat via z-ai-web-dev-sdk
│   ├── globals.css                # Purple + turquoise theme
│   ├── layout.tsx                 # Fonts, PWA metadata, viewport
│   └── page.tsx                   # Main app shell (chat + sidebar + topics)
├── components/
│   ├── chat-input.tsx             # Textarea + voice input + suggestion chips
│   ├── chat-message.tsx          # Chat bubbles + typing indicator
│   ├── language-switcher.tsx     # fa/en/zh dropdown + theme toggle
│   ├── topic-sidebar.tsx         # Topic chips + word list + progress
│   └── word-card.tsx              # Word, translation, phonetic, definition, audio
├── data/
│   └── words.ts                   # 1170 words × 22 topics, auto-generated
└── lib/
    ├── i18n.ts                    # Persian/English/Chinese string tables
    └── store.ts                   # Zustand store (persisted)

public/
├── manifest.json                  # PWA manifest
├── icon.svg, icon-192.png, icon-512.png

.github/workflows/build-apk.yml    # Auto APK build on every push
```

## 🔁 Regenerate the word list

```bash
python scripts/generate_words.py
```

## 🛠 Tech stack

| Layer | Tool |
|---|---|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 |
| UI components | shadcn/ui (New York) |
| State | Zustand + persist |
| AI | z-ai-web-dev-sdk (server only) |
| Dictionary | dictionaryapi.dev + datamuse.com |
| Android build | GitHub Actions + Capacitor |
| Fonts | Inter, Noto Sans Arabic, Noto Sans SC |

## 📜 License

MIT — free to use, modify, and share.

## 👤 Author

`ssijendn9-blip` — <ssijendn9@gmail.com>
