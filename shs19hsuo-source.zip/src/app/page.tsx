"use client";

import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";
import { useT, LanguageSwitcher, ThemeToggle } from "@/components/language-switcher";
import { TopicSidebar } from "@/components/topic-sidebar";
import { ChatMessageList } from "@/components/chat-message";
import { ChatInput } from "@/components/chat-input";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu, GraduationCap, Info, X } from "lucide-react";
import { LOCALE_META } from "@/lib/i18n";
import { TOTAL_WORDS, TOTAL_TOPICS } from "@/data/words";

export default function Home() {
  const tt = useT();
  const locale = useAppStore((s) => s.locale);
  const messages = useAppStore((s) => s.messages);
  const addMessage = useAppStore((s) => s.addMessage);
  const [mounted, setMounted] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);

  useEffect(() => {
    // Defer to a microtask so we don't trigger cascading renders in effect body
    let active = true;
    Promise.resolve().then(() => {
      if (active) setMounted(true);
    });
    return () => {
      active = false;
    };
  }, []);

  // Set <html dir> & <html lang> based on locale
  useEffect(() => {
    if (!mounted) return;
    const meta = LOCALE_META[locale];
    document.documentElement.lang = locale;
    document.documentElement.dir = meta.dir;
  }, [locale, mounted]);

  // Apply theme
  const theme = useAppStore((s) => s.theme);
  useEffect(() => {
    if (!mounted) return;
    const apply = (mode: "light" | "dark") => {
      document.documentElement.classList.toggle("dark", mode === "dark");
    };
    if (theme === "system") {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      apply(mq.matches ? "dark" : "light");
      const handler = (e: MediaQueryListEvent) =>
        apply(e.matches ? "dark" : "light");
      mq.addEventListener("change", handler);
      return () => mq.removeEventListener("change", handler);
    }
    apply(theme);
  }, [theme, mounted]);

  // Seed a welcome message on first mount
  useEffect(() => {
    if (!mounted) return;
    if (messages.length === 0) {
      addMessage({ role: "assistant", content: tt("welcome") });
    }
  }, [mounted, locale]);

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading…</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-border bg-card/70 backdrop-blur-xl">
        <div className="flex items-center gap-2 px-3 sm:px-4 h-14">
          {/* Mobile topic drawer trigger */}
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                aria-label="Open topics"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side={locale === "fa" ? "right" : "left"}
              className="w-[85%] sm:w-[380px] p-0"
            >
              <TopicSidebar />
            </SheetContent>
          </Sheet>

          <div className="flex items-center gap-2 flex-1 min-w-0">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shrink-0">
              <GraduationCap className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold leading-tight gradient-text truncate">
                {tt("appTitle")}
              </h1>
              <p className="text-[11px] text-muted-foreground truncate">
                {tt("appSubtitle")}
              </p>
            </div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setAboutOpen(true)}
            aria-label="About"
          >
            <Info className="h-5 w-5" />
          </Button>
          <ThemeToggle />
          <LanguageSwitcher />
        </div>
      </header>

      {/* Main split: sidebar + chat */}
      <main className="flex-1 flex overflow-hidden">
        {/* Desktop sidebar */}
        <aside className="hidden lg:flex w-[340px] shrink-0 border-e border-border bg-card/30">
          <div className="w-full">
            <TopicSidebar />
          </div>
        </aside>

        {/* Chat area */}
        <section className="flex-1 flex flex-col min-w-0">
          <div className="flex-1 overflow-y-auto px-3 sm:px-4 py-4">
            <ChatMessageList />
          </div>
          <ChatInput />
        </section>
      </main>

      {/* About modal */}
      {aboutOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setAboutOpen(false)}
        >
          <div
            className="bg-card border border-border rounded-2xl p-6 max-w-md w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <GraduationCap className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-bold">{tt("aboutApp")}</h3>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setAboutOpen(false)}
                className="h-7 w-7"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              {tt("aboutDescription")}
            </p>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="rounded-lg bg-primary/10 p-3 text-center">
                <div className="text-2xl font-bold gradient-text">{TOTAL_WORDS}+</div>
                <div className="text-xs text-muted-foreground">{tt("totalWords")}</div>
              </div>
              <div className="rounded-lg bg-secondary/20 p-3 text-center">
                <div className="text-2xl font-bold gradient-text">{TOTAL_TOPICS}</div>
                <div className="text-xs text-muted-foreground">{tt("topics")}</div>
              </div>
            </div>
            <div className="text-xs text-muted-foreground text-center">
              <p>
                {locale === "fa"
                  ? "ساخته‌شده با Next.js + Tailwind + z-ai-web-dev-sdk"
                  : locale === "zh"
                    ? "基于 Next.js + Tailwind + z-ai-web-dev-sdk 构建"
                    : "Built with Next.js + Tailwind + z-ai-web-dev-sdk"}
              </p>
              <p className="mt-1">
                {locale === "fa"
                  ? "API دیکشنری: dictionaryapi.dev رایگان"
                  : locale === "zh"
                    ? "词典 API: dictionaryapi.dev (免费)"
                    : "Dictionary API: dictionaryapi.dev (free)"}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
