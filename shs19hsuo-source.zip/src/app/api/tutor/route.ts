import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

// AI Tutor chat endpoint.
// Uses z-ai-web-dev-sdk on the backend only (never client-side).

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      messages: ChatMessage[];
      locale: "fa" | "en" | "zh";
    };

    if (!body?.messages || !Array.isArray(body.messages) || body.messages.length === 0) {
      return NextResponse.json({ error: "messages[] required" }, { status: 400 });
    }

    const locale = body.locale ?? "fa";

    const localeNames: Record<string, string> = {
      fa: "Persian (Farsi)",
      en: "English",
      zh: "Chinese (Mandarin, simplified)",
    };

    const systemPrompt = `You are LingoPal, a friendly and patient English-vocabulary tutor.
You help a learner remember, understand, and use 1000 essential English words.

The learner's native UI language is ${localeNames[locale]}. 
Always respond primarily in ${localeNames[locale]}, but ALWAYS include the English word in English script when you talk about it.

Style guidelines:
- Be encouraging, warm and concise. Maximum 90 words per reply.
- Use simple, friendly language. Talk like a caring teacher, not a textbook.
- If the user asks about a word, give: short meaning (in their language), one example English sentence, and the English word used in context.
- If the user gives a greeting, greet back and offer to teach a new word or practice.
- If the user asks a free-form question in ${localeNames[locale]}, respond in ${localeNames[locale]} with any English word in English script.
- You may use simple markdown: **bold** for the English word, *italic* for translations, and line breaks.
- Never invent non-existent English words.
- If the user asks something unrelated to English learning, gently steer back to learning English vocabulary.`;

    const messagesForModel: ChatMessage[] = [
      { role: "system", content: systemPrompt },
      ...body.messages.slice(-12), // keep last 12 messages max for token budget
    ];

    // z-ai-web-dev-sdk default export
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: messagesForModel,
      temperature: 0.7,
      max_tokens: 350,
    });

    const reply =
      completion?.choices?.[0]?.message?.content ??
      completion?.choices?.[0]?.delta?.content ??
      "";

    return NextResponse.json({ reply: reply.trim() || "..." });
  } catch (err) {
    console.error("[tutor] error:", err);
    return NextResponse.json(
      {
        error: "AI tutor unavailable right now. Please try again.",
        reply: "Sorry, I couldn't reach the AI. Try sending your message again.",
      },
      { status: 500 }
    );
  }
}
