import { NextRequest, NextResponse } from "next/server";

// Dictionary proxy with two sources:
//   1. Free Dictionary API (dictionaryapi.dev) - has phonetics + audio
//   2. Datamuse API (datamuse.com) - fallback with definitions from Wiktionary

const CACHE = new Map<string, { data: unknown; expires: number }>();
const CACHE_TTL_MS = 1000 * 60 * 60 * 24; // 24 hours

type Meaning = {
  partOfSpeech: string;
  definitions: Array<{ definition: string; example?: string }>;
};

type DictResponse = {
  word: string;
  phonetic?: string;
  audio?: string;
  meanings?: Meaning[];
  ok?: boolean;
  source?: "dictionaryapi.dev" | "datamuse" | "local-only";
  error?: string;
};

async function fetchFromDictionaryApi(word: string): Promise<DictResponse | null> {
  try {
    const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`;
    const upstream = await fetch(url, {
      headers: {
        Accept: "application/json",
        "User-Agent":
          "LingoPal/1.0 (English learning app; +https://github.com/ssijendn9/lingopal)",
        "Accept-Language": "en-US,en;q=0.9",
      },
      next: { revalidate: 86400 },
    });
    if (!upstream.ok) return null;
    const raw = (await upstream.json()) as Array<{
      phonetic?: string;
      phonetics?: Array<{ text?: string; audio?: string }>;
      meanings?: Array<{
        partOfSpeech?: string;
        definitions?: Array<{ definition?: string; example?: string }>;
      }>;
    }>;
    const first = raw[0];
    if (!first) return null;
    const phoneticText =
      first.phonetic ||
      first.phonetics?.find((p) => p?.text)?.text ||
      "";
    const audioUrl =
      first.phonetics?.find((p) => p?.audio && p.audio.startsWith("https"))?.audio || "";
    const meanings: Meaning[] = (first.meanings ?? []).map((m) => ({
      partOfSpeech: m.partOfSpeech ?? "",
      definitions: (m.definitions ?? []).map((d) => ({
        definition: d.definition ?? "",
        example: d.example ?? "",
      })),
    }));
    return {
      word,
      phonetic: phoneticText,
      audio: audioUrl,
      meanings,
      ok: true,
      source: "dictionaryapi.dev",
    };
  } catch {
    return null;
  }
}

async function fetchFromDatamuse(word: string): Promise<DictResponse | null> {
  try {
    const url = `https://api.datamuse.com/words?sp=${encodeURIComponent(word)}&md=d&max=1`;
    const upstream = await fetch(url, {
      headers: { Accept: "application/json" },
      next: { revalidate: 86400 },
    });
    if (!upstream.ok) return null;
    const raw = (await upstream.json()) as Array<{
      word: string;
      defs?: string[];
    }>;
    const first = raw?.[0];
    if (!first || !first.defs?.length) return null;
    // Datamuse defs are formatted as "pos\tdefinition"
    const meanings: Meaning[] = [];
    const byPos = new Map<string, Array<{ definition: string; example?: string }>>();
    for (const d of first.defs.slice(0, 6)) {
      const [pos, ...rest] = d.split("\t");
      const definition = rest.join("\t").trim();
      if (!definition) continue;
      const posNorm = (pos || "n").charAt(0).toLowerCase();
      const posFull =
        posNorm === "v" ? "verb" :
        posNorm === "n" ? "noun" :
        posNorm === "a" || posNorm === "s" ? "adjective" :
        posNorm === "r" ? "adverb" :
        pos;
      if (!byPos.has(posFull)) byPos.set(posFull, []);
      byPos.get(posFull)!.push({ definition });
    }
    for (const [pos, defs] of byPos) {
      meanings.push({ partOfSpeech: pos, definitions: defs });
    }
    return {
      word,
      meanings,
      ok: true,
      source: "datamuse",
    };
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const word = req.nextUrl.searchParams.get("word")?.trim().toLowerCase();
  if (!word) {
    return NextResponse.json({ error: "Missing 'word' parameter" }, { status: 400 });
  }

  const cached = CACHE.get(word);
  if (cached && cached.expires > Date.now()) {
    return NextResponse.json(cached.data);
  }

  // Try Free Dictionary API first (has phonetics + audio), then fall back to Datamuse
  let data: DictResponse | null = await fetchFromDictionaryApi(word);
  if (!data) {
    data = await fetchFromDatamuse(word);
  }

  if (!data) {
    // Both APIs failed — return a graceful response with just the word.
    // The UI will fall back to the local translation.
    const fallback: DictResponse = {
      word,
      ok: false,
      source: "local-only",
      error: "Both dictionary APIs are unavailable right now. Showing local translation only.",
    };
    CACHE.set(word, { data: fallback, expires: Date.now() + 1000 * 60 * 5 }); // short cache for fallback
    return NextResponse.json(fallback);
  }

  CACHE.set(word, { data, expires: Date.now() + CACHE_TTL_MS });
  return NextResponse.json(data);
}
