"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Locale } from "@/lib/i18n";

export type ChatRole = "user" | "assistant" | "system";

export type ChatMessage = {
  id: string;
  role: ChatRole;
  content: string;
  ts: number;
  // Optional attached word card
  wordId?: string;
  word?: string;
};

type AppState = {
  // Settings
  locale: Locale;
  theme: "light" | "dark" | "system";
  // Learning state
  learnedWordIds: string[];
  selectedTopicId: string | null;
  selectedWordId: string | null;
  // Chat
  messages: ChatMessage[];
  isAITyping: boolean;
  // Actions
  setLocale: (l: Locale) => void;
  setTheme: (t: "light" | "dark" | "system") => void;
  toggleLearned: (wordId: string) => void;
  isLearned: (wordId: string) => boolean;
  setSelectedTopic: (topicId: string | null) => void;
  setSelectedWord: (wordId: string | null) => void;
  addMessage: (m: Omit<ChatMessage, "id" | "ts">) => void;
  setAITyping: (v: boolean) => void;
  clearMessages: () => void;
};

function uid() {
  return `m_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      locale: "fa",
      theme: "system",
      learnedWordIds: [],
      selectedTopicId: null,
      selectedWordId: null,
      messages: [],
      isAITyping: false,

      setLocale: (l) => set({ locale: l }),
      setTheme: (t) => set({ theme: t }),

      toggleLearned: (wordId) =>
        set((s) => {
          const has = s.learnedWordIds.includes(wordId);
          return {
            learnedWordIds: has
              ? s.learnedWordIds.filter((w) => w !== wordId)
              : [...s.learnedWordIds, wordId],
          };
        }),

      isLearned: (wordId) => get().learnedWordIds.includes(wordId),

      setSelectedTopic: (topicId) => set({ selectedTopicId: topicId, selectedWordId: null }),
      setSelectedWord: (wordId) => set({ selectedWordId: wordId }),

      addMessage: (m) =>
        set((s) => ({
          messages: [...s.messages, { ...m, id: uid(), ts: Date.now() }],
        })),

      setAITyping: (v) => set({ isAITyping: v }),

      clearMessages: () => set({ messages: [] }),
    }),
    {
      name: "lingopal-app-store",
      // Don't persist isAITyping
      partialize: (s) => ({
        locale: s.locale,
        theme: s.theme,
        learnedWordIds: s.learnedWordIds,
        selectedTopicId: s.selectedTopicId,
        selectedWordId: s.selectedWordId,
        messages: s.messages.slice(-50), // keep last 50 only
      }),
    }
  )
);
