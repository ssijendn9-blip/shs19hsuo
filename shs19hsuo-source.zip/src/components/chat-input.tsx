"use client";

import { useState, useRef, useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { useT } from "@/components/language-switcher";
import { Button } from "@/components/ui/button";
import { Send, Mic, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export function ChatInput() {
  const tt = useT();
  const locale = useAppStore((s) => s.locale);
  const messages = useAppStore((s) => s.messages);
  const addMessage = useAppStore((s) => s.addMessage);
  const setAITyping = useAppStore((s) => s.setAITyping);
  const [text, setText] = useState("");
  const [listening, setListening] = useState(false);
  const taRef = useRef<HTMLTextAreaElement | null>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-grow textarea
  useEffect(() => {
    if (taRef.current) {
      taRef.current.style.height = "auto";
      taRef.current.style.height = `${Math.min(taRef.current.scrollHeight, 120)}px`;
    }
  }, [text]);

  const sendToTutor = async (userText: string) => {
    if (!userText.trim()) return;
    addMessage({ role: "user", content: userText });
    setText("");
    setAITyping(true);

    try {
      const res = await fetch("/api/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          locale,
          messages: [
            ...messages
              .filter((m) => m.role !== "system")
              .slice(-8)
              .map((m) => ({ role: m.role, content: m.content || m.word || "" })),
            { role: "user", content: userText },
          ],
        }),
      });
      const data = await res.json();
      const reply =
        data.reply ||
        data.error ||
        (locale === "fa"
          ? "متأسفم، خطایی رخ داد."
          : locale === "zh"
            ? "抱歉,出错了。"
            : "Sorry, an error occurred.");
      addMessage({ role: "assistant", content: reply });
    } catch (err) {
      addMessage({
        role: "assistant",
        content:
          locale === "fa"
            ? "🤖 اتصال به معلم برقرار نشد. دوباره تلاش کن."
            : locale === "zh"
              ? "🤖 无法连接到导师,请重试。"
              : "🤖 Could not reach the tutor. Try again.",
      });
    } finally {
      setAITyping(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendToTutor(text);
  };

  // Voice input via Web Speech API
  const toggleListening = () => {
    if (typeof window === "undefined") return;
    const SR =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      alert(
        locale === "fa"
          ? "ورودی صوتی پشتیبانی نمی‌شود."
          : locale === "zh"
            ? "您的浏览器不支持语音输入。"
            : "Voice input not supported."
      );
      return;
    }
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = "en-US";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onresult = (ev: any) => {
      const transcript = ev.results?.[0]?.[0]?.transcript ?? "";
      setText((t) => (t ? `${t} ${transcript}` : transcript));
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    rec.start();
    recognitionRef.current = rec;
    setListening(true);
  };

  // Suggested prompt chips
  const suggestions =
    locale === "fa"
      ? [
          "یک کلمه جدید یادم بده",
          "کلمه apple رو توضیح بده",
          "یک جمله با have بساز",
        ]
      : locale === "zh"
        ? ["教我一个新单词", "解释apple", "用have造一个句子"]
        : ["Teach me a new word", "Explain 'apple'", "Use 'have' in a sentence"];

  return (
    <div className="border-t border-border bg-card/80 backdrop-blur p-3">
      {messages.length === 0 && (
        <div className="flex flex-wrap gap-1.5 mb-2">
          {suggestions.map((s, i) => (
            <button
              key={i}
              onClick={() => sendToTutor(s)}
              className="px-2.5 py-1 rounded-full text-xs border border-border bg-background hover:bg-accent/30 hover:border-primary/40 transition-colors flex items-center gap-1"
            >
              <Sparkles className="h-3 w-3 text-primary" />
              {s}
            </button>
          ))}
        </div>
      )}
      <form onSubmit={handleSubmit} className="flex items-end gap-2">
        <div className="relative flex-1">
          <textarea
            ref={taRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={tt("chatPlaceholder")}
            rows={1}
            dir="auto"
            className="w-full resize-none rounded-2xl px-4 py-2.5 pe-10 text-sm bg-background border border-input focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-colors"
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendToTutor(text);
              }
            }}
          />
          <button
            type="button"
            onClick={toggleListening}
            className={cn(
              "absolute end-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full transition-colors",
              listening
                ? "bg-destructive/20 text-destructive animate-pulse"
                : "text-muted-foreground hover:text-primary hover:bg-accent/40"
            )}
            aria-label="Voice input"
            title={listening ? "Listening..." : "Tap to speak"}
          >
            <Mic className="h-4 w-4" />
          </button>
        </div>
        <Button
          type="submit"
          size="icon"
          disabled={!text.trim()}
          className="h-10 w-10 rounded-full shrink-0 bg-gradient-to-br from-primary to-secondary hover:opacity-90 disabled:opacity-40"
        >
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}
