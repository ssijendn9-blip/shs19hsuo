"use client";

import { useAppStore } from "@/lib/store";
import { useT } from "@/components/language-switcher";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { TOPICS, WORDS, getWordsByTopic, type WordEntry, type Topic } from "@/data/words";

export function TopicSidebar() {
  const tt = useT();
  const locale = useAppStore((s) => s.locale);
  const selectedTopicId = useAppStore((s) => s.selectedTopicId);
  const selectedWordId = useAppStore((s) => s.selectedWordId);
  const setSelectedTopic = useAppStore((s) => s.setSelectedTopic);
  const setSelectedWord = useAppStore((s) => s.setSelectedWord);
  const learnedWordIds = useAppStore((s) => s.learnedWordIds);
  const addMessage = useAppStore((s) => s.addMessage);

  const [search, setSearch] = useState("");
  // Static imports — no need for state indirection
  const words: WordEntry[] = WORDS;
  const topics: Topic[] = TOPICS;

  const filteredWords = useMemo(() => {
    if (!selectedTopicId) return [];
    let list = getWordsByTopic(selectedTopicId);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (w) =>
          w.word.toLowerCase().includes(q) ||
          w.fa.includes(search) ||
          w.zh.includes(search)
      );
    }
    return list;
  }, [selectedTopicId, search]);

  const handlePickWord = (w: WordEntry) => {
    setSelectedWord(w.id);
    // Show word card as a system message in the chat
    addMessage({
      role: "assistant",
      content: "",
      wordId: w.id,
      word: w.word,
    });
  };

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="p-3 border-b border-border bg-card/50 backdrop-blur">
        <h2 className="text-sm font-semibold text-foreground mb-2">
          {tt("topics")}
        </h2>
        <div className="grid grid-cols-2 gap-2 mb-2">
          <div className="rounded-lg bg-primary/10 p-2 text-center">
            <div className="text-xs text-muted-foreground">{tt("learned")}</div>
            <div className="text-lg font-bold text-primary">{learnedWordIds.length}</div>
          </div>
          <div className="rounded-lg bg-secondary/20 p-2 text-center">
            <div className="text-xs text-muted-foreground">{tt("totalWords")}</div>
            <div className="text-lg font-bold text-secondary-foreground">
              {words.length || 1170}
            </div>
          </div>
        </div>
        <Progress
          value={words.length ? (learnedWordIds.length / words.length) * 100 : 0}
          className="h-1.5"
        />
      </div>

      {/* Topic chips */}
      <div className="p-3 border-b border-border">
        <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto">
          {topics.map((tp) => {
            const isActive = selectedTopicId === tp.id;
            const topicLearned = learnedWordIds.filter((id) => {
              const w = words.find((x) => x.id === id);
              return w?.topic === tp.id;
            }).length;
            const total = words.filter((w) => w.topic === tp.id).length;
            return (
              <button
                key={tp.id}
                onClick={() => setSelectedTopic(isActive ? null : tp.id)}
                className={cn(
                  "px-2 py-1 rounded-full text-xs font-medium transition-all",
                  "border border-border hover:border-primary/50",
                  isActive
                    ? "bg-gradient-to-br from-primary to-secondary text-primary-foreground border-transparent shadow"
                    : "bg-card text-foreground hover:bg-accent/30"
                )}
                title={`${topicLearned}/${total}`}
              >
                <span className="mr-1">{tp.icon}</span>
                {locale === "fa" ? tp.fa : locale === "zh" ? tp.zh : tp.en}
              </button>
            );
          })}
        </div>
      </div>

      {/* Search box */}
      {selectedTopicId && (
        <div className="p-3 border-b border-border">
          <div className="relative">
            <Search className="absolute start-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={tt("searchWord")}
              className="w-full ps-8 pe-3 py-1.5 rounded-md text-sm bg-background border border-input focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary transition-colors"
            />
          </div>
        </div>
      )}

      {/* Word list */}
      <ScrollArea className="flex-1">
        {!selectedTopicId ? (
          <div className="p-4 text-center text-sm text-muted-foreground">
            {tt("selectTopicPrompt")}
          </div>
        ) : filteredWords.length === 0 ? (
          <div className="p-4 text-center text-sm text-muted-foreground">
            {tt("noResults")}
          </div>
        ) : (
          <ul className="p-2 space-y-0.5">
            {filteredWords.map((w) => {
              const isLearned = learnedWordIds.includes(w.id);
              const isActive = selectedWordId === w.id;
              return (
                <li key={w.id}>
                  <button
                    onClick={() => handlePickWord(w)}
                    className={cn(
                      "w-full text-start px-3 py-2 rounded-lg transition-colors group flex items-center justify-between gap-2",
                      isActive
                        ? "bg-primary/15 border border-primary/30"
                        : "hover:bg-accent/30 border border-transparent"
                    )}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-foreground">{w.word}</span>
                        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                          {w.level}
                        </span>
                      </div>
                      <div
                        className="text-xs text-muted-foreground truncate"
                        dir={locale === "fa" ? "rtl" : "ltr"}
                      >
                        {locale === "fa" ? w.fa : locale === "zh" ? w.zh : w.fa}
                      </div>
                    </div>
                    {isLearned && (
                      <span className="shrink-0 h-2 w-2 rounded-full bg-primary" aria-label="learned" />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </ScrollArea>
    </div>
  );
}
