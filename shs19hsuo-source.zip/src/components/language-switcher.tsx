"use client";

import { useAppStore } from "@/lib/store";
import { LOCALES, LOCALE_META, t } from "@/lib/i18n";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Languages } from "lucide-react";

export function LanguageSwitcher() {
  const { locale, setLocale } = useAppStore();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2 px-2.5">
          <Languages className="h-4 w-4" />
          <span className="text-sm font-medium">{LOCALE_META[locale].nativeName}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[10rem]">
        {LOCALES.map((l) => (
          <DropdownMenuItem
            key={l}
            onSelect={() => setLocale(l)}
            className={`gap-2 ${l === locale ? "bg-accent/40" : ""}`}
          >
            <span className="text-base">{LOCALE_META[l].flag}</span>
            <span className="font-medium">{LOCALE_META[l].nativeName}</span>
            {l === locale && <span className="ms-auto text-xs text-primary">●</span>}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function ThemeToggle() {
  const { theme, setTheme } = useAppStore();
  const cycle = () => {
    const order: ("light" | "dark" | "system")[] = ["light", "dark", "system"];
    const idx = order.indexOf(theme);
    setTheme(order[(idx + 1) % order.length]);
  };
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={cycle}
      className="gap-2 px-2.5"
      aria-label="Toggle theme"
    >
      <span className="text-sm capitalize">{theme}</span>
    </Button>
  );
}

// Convenience hook for translations in components
export function useT() {
  const locale = useAppStore((s) => s.locale);
  return (key: string, params?: Record<string, string | number>) => t(locale, key, params);
}
