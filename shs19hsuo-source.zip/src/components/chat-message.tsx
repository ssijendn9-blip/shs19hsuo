"use client";

import { useAppStore, type ChatMessage } from "@/lib/store";
import { useT } from "@/components/language-switcher";
import { cn } from "@/lib/utils";
import { Bot, User, Loader2 } from "lucide-react";
import { WordCard } from "@/components/word-card";
import { useEffect, useRef } from "react";
import { useAppStore as useStore } from "@/lib/store";

export function ChatBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  return (
    <div
      className={cn(
        "flex w-full gap-2 sm:gap-3 bubble-in",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      {!isUser && (
        <div className="shrink-0 mt-0.5">
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-primary-foreground">
            <Bot className="h-4 w-4" />
          </div>
        </div>
      )}
      <div className={cn("max-w-[80%] sm:max-w-[70%]", isUser && "order-1")}>
        {message.wordId ? (
          <div className="rounded-2xl">
            <WordCard wordId={message.wordId} />
          </div>
        ) : (
          <div
            className={cn(
              "rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm whitespace-pre-wrap break-words",
              isUser
                ? "bg-gradient-to-br from-primary to-primary text-primary-foreground rounded-br-md"
                : "bg-card text-card-foreground border border-border rounded-bl-md"
            )}
          >
            {message.content}
          </div>
        )}
        <div
          className={cn(
            "text-[10px] text-muted-foreground mt-1 px-1",
            isUser ? "text-right" : "text-left"
          )}
        >
          {new Date(message.ts).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </div>
      </div>
      {isUser && (
        <div className="shrink-0 mt-0.5">
          <div className="h-8 w-8 rounded-full bg-muted border border-border flex items-center justify-center text-muted-foreground">
            <User className="h-4 w-4" />
          </div>
        </div>
      )}
    </div>
  );
}

export function ChatTypingIndicator() {
  return (
    <div className="flex justify-start gap-2 sm:gap-3 bubble-in">
      <div className="shrink-0 mt-0.5">
        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-primary-foreground">
          <Bot className="h-4 w-4" />
        </div>
      </div>
      <div className="rounded-2xl px-4 py-3 bg-card border border-border rounded-bl-md flex items-center gap-1.5">
        <span className="h-2 w-2 rounded-full bg-primary/70 pulse-dot" />
        <span className="h-2 w-2 rounded-full bg-primary/70 pulse-dot" style={{ animationDelay: "0.2s" }} />
        <span className="h-2 w-2 rounded-full bg-primary/70 pulse-dot" style={{ animationDelay: "0.4s" }} />
      </div>
    </div>
  );
}

export function ChatMessageList() {
  const messages = useStore((s) => s.messages);
  const isAITyping = useStore((s) => s.isAITyping);
  const tt = useT();
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, isAITyping]);

  if (messages.length === 0) {
    return (
      <div className="text-center text-muted-foreground text-sm py-12 px-4">
        <div className="mx-auto h-14 w-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-3">
          <Bot className="h-7 w-7 text-primary-foreground" />
        </div>
        <p className="leading-relaxed">{tt("welcome")}</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 px-1 py-2">
      {messages.map((m) => (
        <ChatBubble key={m.id} message={m} />
      ))}
      {isAITyping && <ChatTypingIndicator />}
      <div ref={endRef} />
    </div>
  );
}
