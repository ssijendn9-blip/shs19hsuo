"use client";

import { useAppStore } from "@/lib/store";
import { useT } from "@/components/language-switcher";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Volume2, Check, Bookmark } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

type DictData = {
  word: string;
  phonetic?: string;
  audio?: string;
  meanings?: Array<{
    partOfSpeech: string;
    definitions: Array<{ definition: string; example?: string }>;
  }>;
  ok?: boolean;
  error?: string;
};

type FetchState =
  | { status: "idle"; word: string }
  | { status: "loading"; word: string }
  | { status: "done"; word: string; data: DictData }
  | { status: "error"; word: string; data: DictData };

export function WordCard({ wordId }: { wordId: string }) {
  const locale = useAppStore((s) => s.locale);
  const tt = useT();
  const toggleLearned = useAppStore((s) => s.toggleLearned);
  const isLearned = useAppStore((s) => s.learnedWordIds.includes(wordId));
  const addMessage = useAppStore((s) => s.addMessage);

  // Find word from data
  const word = useWord(wordId);
  const [fetchState, setFetchState] = useState<FetchState>({ status: "idle", word: "" });
  const [showMeaning, setShowMeaning] = useState(false);

  useEffect(() => {
    if (!word) return;
    const wordStr = word.word;
    let cancelled = false;
    const controller = new AbortController();
    // Mark loading asynchronously (after the current commit), via a microtask,
    // so we don't trigger a synchronous cascading render from the effect body.
    Promise.resolve().then(() => {
      if (!cancelled) {
        setFetchState((prev) =>
          prev.word === wordStr && prev.status === "done"
            ? prev
            : { status: "loading", word: wordStr }
        );
      }
    });
    fetch(`/api/dictionary?word=${encodeURIComponent(wordStr)}`, {
      signal: controller.signal,
    })
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setFetchState({ status: "done", word: wordStr, data: d });
      })
      .catch((err) => {
        if (!cancelled && err.name !== "AbortError") {
          setFetchState({
            status: "error",
            word: wordStr,
            data: { word: wordStr, error: "fetch_failed" },
          });
        }
      });
    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [word?.word]);

  if (!word) return null;

  // Derive loading status: loading if requested word doesn't match fetched word
  const isLoading =
    fetchState.status === "loading" ||
    (fetchState.word !== word.word && fetchState.status !== "idle");
  const dict =
    fetchState.status === "done" || fetchState.status === "error"
      ? fetchState.word === word.word
        ? fetchState.data
        : null
      : null;

  const speak = () => {
    if (typeof window === "undefined") return;
    const utter = new SpeechSynthesisUtterance(word.word);
    utter.lang = "en-US";
    utter.rate = 0.9;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utter);
  };

  const playAudio = () => {
    if (dict?.audio) {
      const audio = new Audio(dict.audio);
      audio.play().catch(() => speak());
    } else {
      speak();
    }
  };

  // Translation in user's language
  const translation = locale === "en" ? "" : locale === "fa" ? word.fa : word.zh;
  const translationLabel = locale === "fa" ? "معنی" : locale === "zh" ? "释义" : "Meaning";

  return (
    <Card className="overflow-hidden border-0 gradient-border shadow-lg">
      <div className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-2xl sm:text-3xl font-bold text-foreground">
                {word.word}
              </h3>
              {dict?.phonetic && (
                <span className="text-sm text-muted-foreground font-mono">
                  {dict.phonetic}
                </span>
              )}
              <Badge variant="secondary" className="text-[10px] uppercase">
                {word.level}
              </Badge>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Button
              variant="ghost"
              size="icon"
              onClick={playAudio}
              className="h-9 w-9"
              aria-label={tt("listen")}
              title={tt("tapToHear")}
            >
              <Volume2 className="h-5 w-5 text-primary" />
            </Button>
            <Button
              variant={isLearned ? "default" : "ghost"}
              size="icon"
              onClick={() => toggleLearned(wordId)}
              className="h-9 w-9"
              aria-label={tt("markLearned")}
            >
              <Check className={cn("h-5 w-5", isLearned && "text-primary-foreground")} />
            </Button>
          </div>
        </div>

        {/* Native-language translation */}
        {translation && (
          <div className="mt-3 p-3 rounded-lg bg-primary/10 border border-primary/20">
            <div className="text-[11px] uppercase tracking-wider text-primary/80 mb-0.5">
              {translationLabel}
            </div>
            <div className="text-lg font-semibold text-foreground" dir={locale === "fa" ? "rtl" : "ltr"}>
              {translation}
            </div>
          </div>
        )}

        {/* English definition */}
        <div className="mt-3">
          {isLoading ? (
            <div className="text-sm text-muted-foreground animate-pulse">
              {tt("fetchingWord")}
            </div>
          ) : dict?.ok && dict.meanings?.length ? (
            <div className="space-y-2">
              {dict.meanings.slice(0, 2).map((m, i) => (
                <div key={i} className="text-sm">
                  <span className="text-[11px] uppercase tracking-wider text-accent-foreground/80 italic me-2">
                    {m.partOfSpeech}
                  </span>
                  <span className="text-foreground">
                    {m.definitions[0]?.definition}
                  </span>
                  {m.definitions[0]?.example && (
                    <div className="mt-1 text-muted-foreground italic text-[13px]">
                      “{m.definitions[0].example}”
                    </div>
                  )}
                </div>
              ))}
              {dict.meanings.length > 2 && (
                <button
                  onClick={() => setShowMeaning((v) => !v)}
                  className="text-xs text-primary hover:underline"
                >
                  {showMeaning
                    ? tt("hideMeaning")
                    : `${tt("showMeaning")} (+${dict.meanings.length - 2})`}
                </button>
              )}
              {showMeaning &&
                dict.meanings.slice(2).map((m, i) => (
                  <div key={`extra-${i}`} className="text-sm">
                    <span className="text-[11px] uppercase tracking-wider text-accent-foreground/80 italic me-2">
                      {m.partOfSpeech}
                    </span>
                    <span className="text-foreground">
                      {m.definitions[0]?.definition}
                    </span>
                  </div>
                ))}
            </div>
          ) : (
            <div className="text-sm text-muted-foreground">
              {tt("apiError")}
            </div>
          )}
        </div>

        {/* Quick "ask AI" hint */}
        <button
          onClick={() =>
            addMessage({
              role: "user",
              content: `Teach me the word "${word.word}" — give me a short example and a tip.`,
            })
          }
          className="mt-3 inline-flex items-center gap-1 text-xs text-primary hover:underline"
        >
          <Bookmark className="h-3 w-3" />
          {locale === "fa" ? "از معلم بپرس" : locale === "zh" ? "问导师" : "Ask the tutor"}
        </button>
      </div>
    </Card>
  );
}

// Helper hook to find a word from the data
function useWord(wordId: string) {
  const [word, setWord] = useState<null | {
    id: string;
    word: string;
    topic: string;
    level: string;
    fa: string;
    zh: string;
  }>(null);
  useEffect(() => {
    import("@/data/words").then((m) => {
      const w = m.getWord(wordId) ?? null;
      setWord((prev) => (prev?.id === w?.id ? prev : w));
    });
  }, [wordId]);
  return word;
}
